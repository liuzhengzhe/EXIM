import os,glob
paths=glob.glob('/mnt/sda/lzz/ifnet/mesh_text/*.obj')
paths.sort()
for path in paths:
  name=path.split('/')[-1].replace(' ','')

  
  if os.path.exists('/home/user/text/'+name):
    continue
  #  #if os.path.getsize('/home/user/text/'+name+'/mesh_text/mesh_text_r_000.png')>0:
  #  #  continue'''
  try:
    os.mkdir('/home/user/text/'+name)
  except:
    pass
    
    
  print ('blender --background --python render_blender.py -- --output_folder /home/user/text/'+name+' '+path.replace(' ','\ '))
  os.system('blender --background --python render_blender.py -- --output_folder /home/user/text/'+name+' '+path.replace(' ','\ '))
  #os.system('blender --background --python render_blender.py -- --output_folder . '+path)