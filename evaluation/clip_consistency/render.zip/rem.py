import glob,os
import shutil
paths=glob.glob('/home/user/text/*')
paths.sort()
for path in paths:
  name=path.split('/')[-1]#.replace(' ','')
  
  imgs=glob.glob('/home/user/text/'+name+'/mesh_text/mesh_text_r_000.png')[0]

  if os.path.getsize(imgs)==0:
    print (path)
    #shutil.rmtree(path)

  
  #if os.path.exists('/home/user/text/'+name):
  #  continue